





!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="9b7990f8-1f25-571a-a422-03bea91eb8ab")}catch(e){}}();
function bar() {
    Sentry.captureException(new Error("Sentry Test Error"));
}

function foo() {
    bar();
}

function captureException() {
    foo();
}

//# debugId=9b7990f8-1f25-571a-a422-03bea91eb8ab
